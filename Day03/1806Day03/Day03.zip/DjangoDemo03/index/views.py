from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.urls import reverse


def parent_views(request):
  list = ['首页','服装鞋帽','食品','夺宝']
  return render(request,'01-parent.html',locals())

def child_views(request):
  list = ['首页', '服装鞋帽', '食品', '夺宝']
  return render(request,'02-child.html',locals())

def arguments_views(request,year,month):
  return HttpResponse('年份:'+year+',月份:'+month)

def reverse_views(request):
  # url = reverse('parent')
  url = reverse('arg',args=('2018','12'))
  return HttpResponse('解析的地址为:'+url)