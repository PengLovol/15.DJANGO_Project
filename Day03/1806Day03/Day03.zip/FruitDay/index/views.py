from django.shortcuts import render

# Create your views here.
#　http://localhost:8000/login
def login_views(request):
  return render(request,'login.html')

def register_views(request):
  return render(request,'register.html')